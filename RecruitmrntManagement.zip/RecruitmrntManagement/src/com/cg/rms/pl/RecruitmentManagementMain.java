package com.cg.rms.pl;

import java.util.Scanner;

import com.cg.rms.bean.CompanyMaster;
import com.cg.rms.exception.RecruitmentManagementException;
import com.cg.rms.service.IRmsService;
import com.cg.rms.service.IRmsServiceImpl;

public class RecruitmentManagementMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		IRmsService rser = new IRmsServiceImpl();
		

		do {
			System.out.println("Menu");
			System.out.println("1. Insert company details");
			System.out.println("2. update company details");
			
			int choice = sc.nextInt();
			
			switch(choice) {
			case 1:
				try {
					System.out.println("Enter Company Name :");
					String company_name = sc.next();
					System.out.println("Enter company Address :");
					String company_address = sc.next();
					System.out.println("Enter contact person :");
					String contact_person = sc.next();
					System.out.println("Enter email id");
					String email_id = sc.next();
					System.out.println("Enter contact number");
					String contact_number = sc.next();
					
					CompanyMaster cmaster = new CompanyMaster();
					cmaster.setCompany_name(company_name);
					cmaster.setCompany_address(company_address);
					cmaster.setContact_person(contact_person);
					cmaster.setEmail_id(email_id);
					cmaster.setContact_number(contact_number);
					String comp_id=rser.addCompanyDetails(cmaster);
					System.out.println("Successfully registered with registration id :"+comp_id);
				}catch (RecruitmentManagementException e) {
					System.out.println(e.getMessage());
		
				}
				break;
				
			case 2:
				try {
					boolean b = rser.updateCompanyDetails();
					if(b) {
						System.out.println("Details updated s");
					}
				} catch (RecruitmentManagementException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				break;

			}


		}while(true);
	
}}