package com.cg.rms.bean;

public class CompanyMaster {
	
	private String company_id;
	private String company_name;
	private String company_address;
	private String contact_person;
	private String email_id;
	private String contact_number;
	
	public CompanyMaster(){
		
	}

	public String getCompany_id() {
		return company_id;
	}

	public void setCompany_id(String company_id) {
		this.company_id = company_id;
	}

	public String getCompany_name() {
		return company_name;
	}

	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	public String getCompany_address() {
		return company_address;
	}

	public void setCompany_address(String company_address) {
		this.company_address = company_address;
	}

	public String getContact_person() {
		return contact_person;
	}

	public void setContact_person(String contact_person) {
		this.contact_person = contact_person;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getContact_number() {
		return contact_number;
	}

	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}

	public CompanyMaster(String company_id, String company_name,
			String company_address, String contact_person, String email_id,
			String contact_number) {
		super();
		this.company_id = company_id;
		this.company_name = company_name;
		this.company_address = company_address;
		this.contact_person = contact_person;
		this.email_id = email_id;
		this.contact_number = contact_number;
	}

	@Override
	public String toString() {
		return "CompanyMaster [company_id=" + company_id + ", company_name="
				+ company_name + ", company_address=" + company_address
				+ ", contact_person=" + contact_person + ", email_id="
				+ email_id + ", contact_number=" + contact_number + "]";
	}
	
	

}
