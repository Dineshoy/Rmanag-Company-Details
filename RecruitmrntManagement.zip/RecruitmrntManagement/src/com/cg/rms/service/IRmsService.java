package com.cg.rms.service;

import com.cg.rms.bean.CompanyMaster;
import com.cg.rms.exception.RecruitmentManagementException;

public interface IRmsService {
	public String addCompanyDetails(CompanyMaster cmaster) throws RecruitmentManagementException;
	public boolean updateCompanyDetails() throws RecruitmentManagementException;
	
}
