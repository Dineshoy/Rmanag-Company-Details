package com.cg.rms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.cg.rms.bean.CompanyMaster;
import com.cg.rms.exception.RecruitmentManagementException;

public class IRmsDaoImpl implements IRmsDao {
	
	private Connection conn;
	
	private String generateRegistrationId() throws RecruitmentManagementException{
		String sql = "SELECT seq_company_id.NEXTVAl FROM DUAL";
		conn = DBUtil.getConnection();
		try {
		Statement st = conn.createStatement();
		ResultSet rst = st.executeQuery(sql);
		rst.next();
		return rst.getString(1);
	}catch (SQLException e) {
		throw new RecruitmentManagementException("problem in generating reg id"+e.getMessage());
	}
	}

	@Override
	public String addCompanyDetails(CompanyMaster cmaster) throws RecruitmentManagementException {
		
		cmaster.setCompany_id(generateRegistrationId());
		String sql ="INSERT INTO company_master VALUES(?,?,?,?,?,?)";
		conn = DBUtil.getConnection();
		try {
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setString(1, cmaster.getCompany_id());
		pst.setString(2, cmaster.getCompany_name());
		pst.setString(3, cmaster.getCompany_address());
		pst.setString(4, cmaster.getContact_person());
		pst.setString(5, cmaster.getEmail_id());
		pst.setString(6, cmaster.getContact_number());
		pst.executeUpdate();
		//logger.info("Registration completed successfully for"+cmaster);
		
	}catch (SQLException e) {
		throw new RecruitmentManagementException("problem in inserting"
				+"registration details"+e.getMessage());
	}
		return cmaster.getCompany_id();
	}

	@Override
	public boolean updateCompanyDetails() throws RecruitmentManagementException {			
		

		Scanner sc = new Scanner(System.in);
		System.out.println("enter company ID");
		String	id = sc.next();
	
	
	
	
		
		String sql = "UPDATE company_master SET company_name =?, company_address=?, contact_person=?, email_id=?, contact_number=? where company_id=?"; 
		conn = DBUtil.getConnection();
		PreparedStatement pst;
		System.out.println("Enter New Name of Company");
		String nm = sc.next();
		System.out.println("enter company Address");
		String add = sc.next();
		System.out.println("enter contact person");
		String dob=sc.next();
		System.out.println("enter Email ID");
		String email=sc.next();
		System.out.println("enter contact no");
		String cno=sc.next();
		
		
		try {
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, nm);
			pst.setString(2, add);
			pst.setString(3, dob);
			pst.setString(4, email);
			pst.setString(5, cno);
			pst.setString(6, id);
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new RecruitmentManagementException("problem in updating the details"+e.getMessage());
			//e.printStackTrace();
		}
		return true;
		
			
			}
	}
	
