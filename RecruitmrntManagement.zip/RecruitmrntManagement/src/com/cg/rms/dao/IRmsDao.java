package com.cg.rms.dao;

import com.cg.rms.bean.CompanyMaster;
import com.cg.rms.exception.RecruitmentManagementException;

public interface IRmsDao {
	
	public String addCompanyDetails(CompanyMaster cmaster) throws RecruitmentManagementException;
	public boolean updateCompanyDetails() throws RecruitmentManagementException;


}
